##  Car🚗 Detection System

[![forthebadge made-with-python](http://ForTheBadge.com/images/badges/made-with-python.svg)](https://www.python.org/)                 
[![Python 3.6](https://img.shields.io/badge/python-3.6-blue.svg)](https://www.python.org/downloads/release/python-360/)   


### Sourcerer
<a href="https://sourcerer.io/spidy20"><img src="https://avatars2.githubusercontent.com/u/42056100?v=4" height="50px" width="50px" alt=""/></a>

### Code Requirements
- Opencv
- Car XML(Available in repository)


### What steps you have to follow??
- Download my repository 
- And run `Car_detection.py`

### Video demo

[Youtube](https://youtu.be/TiXSnIo5LOo)

## [Follow us on Instagram for Machine Learning Guidelines & Path](https://www.instagram.com/machine_learning_hub.ai/)
## [Donate me on PayPal(It will inspire me to do more projects)](https://www.paypal.me/spidy1820)
## Donate me on GPAY:- kushalbhavsar58-1@okaxis

## Just follow☝️ me and Star⭐ my repository 
